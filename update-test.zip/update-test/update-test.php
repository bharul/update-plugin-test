<?php
/**
 * Update Test
 *
 * @package       UT
 * @author        WorldWin Coder Pvt Ltd
 * @version       2.0
 *
 * @wordpress-plugin
 * Plugin Name:   Update Test
 * Plugin URI:    https://worldwincoder.com
 * Description:   Update Test is plugin use to find new version of the current plugin.
 * Version:       2.0
 * Author:        WorldWin Coder Pvt Ltd
 * Author URI:    https://worldwincoder.com/
 * Text Domain:   update-test
 *
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;

// Update feature
if( ! class_exists( 'WWC_Update_Checker' ) ) {

	class WWC_Update_Checker{

		public $plugin_slug;
		public $version;
		public $cache_key;
		public $cache_allowed;

		public function __construct() {

			$this->plugin_slug = plugin_basename( __DIR__ );
			$this->version = '2.0';
			$this->cache_key = 'wwc_custom_upd';
			$this->cache_allowed = false;

			// add_filter( 'plugins_api', array( $this, 'info' ), 20, 3 );
			add_filter( 'site_transient_update_plugins', array( $this, 'update' ) );
			add_action( 'upgrader_process_complete', array( $this, 'purge' ), 10, 2 );

		}

		function update( $transient ){
 
			if ( empty( $transient->checked ) ) {
				return $transient;
			}
		
			$remote = wp_remote_get( 
				'https://worldwincoder.net/info.json',
				array(
					'timeout' => 10,
					'headers' => array(
						'Accept' => 'application/json'
					)
				)
			);
		
			if( 
				is_wp_error( $remote )
				|| 200 !== wp_remote_retrieve_response_code( $remote )
				|| empty( wp_remote_retrieve_body( $remote )) 
			) {
				return $transient;	
			}
			
			$remote = json_decode( wp_remote_retrieve_body( $remote ) );
			
			
			// your installed plugin version should be on the line below! You can obtain it dynamically of course 
			if(
				$remote
				&& version_compare( $this->version, $remote->version, '<' )
				&& version_compare( $remote->requires, get_bloginfo( 'version' ), '<' )
				&& version_compare( $remote->requires_php, PHP_VERSION, '<' )
			) {
				
				$res = new stdClass();
				$res->slug = $remote->slug;
				$res->plugin = plugin_basename( __FILE__ ); 
				$res->new_version = $remote->version;
				$res->tested = $remote->tested;
				$res->package = $remote->download_url;
				$transient->response[ $res->plugin ] = $res;
				
			}
		 
			return $transient;
		
		}

		public function purge( $upgrader, $options ){

			if (
				$this->cache_allowed
				&& 'update' === $options['action']
				&& 'plugin' === $options[ 'type' ]
			) {
				delete_transient( $this->cache_key );
			}

		}


	}

	new WWC_Update_Checker();

}

class Update_plugin{

	public function __construct(){

		add_action("the_content", array($this, "hello"));

	}

    public function hello(){

        return "Hello World Plugin Updated Successfully";

    }
}

new Update_plugin();